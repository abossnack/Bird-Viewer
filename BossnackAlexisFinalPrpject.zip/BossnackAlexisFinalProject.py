from tkinter import *
from tkinter import ttk
from PIL import ImageTk,Image 
import os, os.path
import random

mainWindow=Tk()

def do_scale(rawImg, scaleWidth):
    width, height = rawImg.size
    h_new = int(round(height * scaleWidth / width, 0))
    return(rawImg.resize((scaleWidth, h_new), Image.ANTIALIAS))

Label( mainWindow, text="Welcome the the bird viewer!", font=("Arial", 16), pady=10, padx=10).pack()

ipath = os.getcwd() + '/bird_icon.jpg'
irimg = Image.open(ipath)
icimg = ImageTk.PhotoImage(do_scale(irimg, 150))
panel = Label(mainWindow, image=icimg, text="Icon image of a bird")
panel.pack()

Label( mainWindow, text="Press the button below to get a picture of a bird", pady=10 ).pack()

lastbird = 0

def finishandexit():
    exit()

def getabird():
    global lastbird

    birdWindow = Toplevel(mainWindow)
    path = os.getcwd() + '/opensourcebirds'
    files = [f for f in os.listdir(path)if os.path.isfile(os.path.join(path, f))]
    rimage = random.randint(0,len(files)-1)
    if (rimage == lastbird):
        rimage = random.randint(0,len(files)-1)

    lastbird = rimage
    rawimg = Image.open(path + "/" + files[rimage])
    
    
    img = ImageTk.PhotoImage(do_scale(rawimg, 500))
    panel = Label(birdWindow, image=img, text="An image of a bird")
    panel.pack(side="bottom", fill="both", expand="yes")
    def exit_tl():
        birdWindow.destroy()
        birdWindow.update()

    Button(birdWindow, text="Close This Bird View", command=exit_tl).pack()
    birdWindow.title('Nice bird')
    birdWindow.mainloop()

Button(mainWindow, text ="View a bird!", command = getabird).pack()
Label(mainWindow, text="Or press the button below to Exit!", pady=5).pack()
Button(mainWindow, text ="Exit Bird Viewer!", command = finishandexit, pady=5).pack()

mainWindow.title('Bird Viewer')
mainWindow.mainloop()